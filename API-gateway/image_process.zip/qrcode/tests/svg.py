from qrcode.image.svg import SvgImage


class SvgImageWhite(SvgImage):
    background = 'white'
