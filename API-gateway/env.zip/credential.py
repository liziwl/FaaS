# -*- coding: utf-8 -*-

# 此处的 API 信息请替换为您的信息，可到 https://console.cloud.tencent.com/capi 获取
appid = 1254095611              # 请替换为您的 APPID
secret_id = u'AKIDpZDyBK6BpMj1DD8USJgO9kHeppeHwy45'   # 请替换为您的 SecretId
secret_key = u'1ymkYBmFWcXHzVuBIEzd7PabeWDjrtkP' # 请替换为您的 SecretKey
region = u'gz'